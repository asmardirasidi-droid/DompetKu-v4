
# DompetKu v4 (Scaffold)

Fitur yang direncanakan:
- Pencatatan pemasukan/pengeluaran
- Tabungan & investasi terpisah
- Target tabungan total
- Export PDF (semua data/per bulan/per tahun)

Struktur awal proyek.
